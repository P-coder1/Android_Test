package com.example.seoil.practice201406655;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class Activity1 extends AppCompatActivity implements View.OnClickListener {
    private static final String LOCAl_FILE = "memo.txt";
    EditText edit01;
    Button btn05;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);

        edit01 = (EditText) findViewById(R.id.editText01);
        btn05 = (Button) findViewById(R.id.button5);
        btn05.setOnClickListener(this);


        InputStream in;
        BufferedReader reader;

        try {
            in = openFileInput(LOCAl_FILE);
        } catch (FileNotFoundException e) {
            in = getResources().openRawResource(R.raw.memo);
        }

        edit01 = (EditText) findViewById(R.id.editText01);

        try {
            reader = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            String s;
            while ((s = reader.readLine()) != null) {
                edit01.append(s);
                edit01.append("\n");
            }
        } catch (IOException e) {
            Log.e("Local File", e.getMessage());
        }

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.test.menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        //save
        return super.onOptionsItemSelected(item);
    }

    protected void onPause() {
        super.onPause();

        edit01 = (EditText) findViewById(R.id.editText01);
        String s = edit01.getText().toString();
        if (s.length() == 0) {
            deleteFile(LOCAl_FILE);
            return;
        }
        try {
            OutputStream out = openFileOutput(LOCAl_FILE, MODE_PRIVATE);
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(out, "UTF-8"));
            writer.append(s);
            writer.close();
        } catch (IOException e) {
            Log.e("Local File", e.getMessage());
        }
    }

    @Override
    public void onClick(View v) {
        finish();
    }
}
