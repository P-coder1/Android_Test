package com.example.seoil.practice201406655;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String LOCAl_FILE = "memo.txt";
    EditText edit01;
    Button btn01,btn02, btn03 ,btn04;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn01 = (Button) findViewById(R.id.button1);
        btn02 = (Button) findViewById(R.id.button2);
        btn03 = (Button) findViewById(R.id.button3);
        btn04 = (Button) findViewById(R.id.button4);

        btn01.setOnClickListener(this);
        btn02.setOnClickListener(this);
        btn03.setOnClickListener(this);
        btn04.setOnClickListener(this);

        InputStream in;
        BufferedReader reader;

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button1) {
            Intent intent01 = new Intent(MainActivity.this, Activity1.class);
            startActivity(intent01);
        }
        if (v.getId() == R.id.button2) {
            Intent intent02 = new Intent(MainActivity.this, Activity2.class);
            startActivity(intent02);
        }
        if (v.getId() == R.id.button3) {
            Intent intent03 = new Intent(MainActivity.this, Activity3.class);
            startActivity(intent03);
        }
        if (v.getId() == R.id.button4) {
            Intent intent04 = new Intent(MainActivity.this, Activity4.class);
            startActivity(intent04);
        }
    }
}
