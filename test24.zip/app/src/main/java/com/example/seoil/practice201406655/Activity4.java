package com.example.seoil.practice201406655;

import android.app.ListActivity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

public class Activity4 extends ListActivity implements View.OnClickListener {
    private String[] list_items = {"practice01","practice02","practice03","practice04","practice05","practice06",
            "practice07","practice08",};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_4);

        setListAdapter(new ArrayAdapter<String>
                (this, android.R.layout.simple_list_item_1, list_items));

        ListView lv =(ListView)findViewById(R.id.listView01);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(this);
    }

    @Override
    public void onClick(View v) {

    }
    @Override
    public void onltemClick(AdapterView<?>) parent, View, int position, long id{
        Toast.makeText(this)
    }
}
