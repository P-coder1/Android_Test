package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ListActivity implements View.OnClickListener {

    private NotesDbAdapter dbAdapter;
    private SimpleCursorAdapter mAdapter;

    private EditText tv1, tv2, tv3;
    private Button insert_btn, update_btn, delete_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1 = (EditText) findViewById(R.id.tv1);
        tv2 = (EditText) findViewById(R.id.tv2);
        tv3 = (EditText) findViewById(R.id.tv3);
        tv1.setEnabled(false);

        insert_btn = (Button) findViewById(R.id.insert_btn);
        update_btn = (Button) findViewById(R.id.update_btn);
        delete_btn = (Button) findViewById(R.id.delete_btn);
        insert_btn.setOnClickListener(this);
        update_btn.setOnClickListener(this);
        delete_btn.setOnClickListener(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        ;
        dbAdapter = new NotesDbAdapter(this);
        dbAdapter.open();
        Cursor c = dbAdapter.fetchAllNotes();
        startManagingCursor(c);

        String[] from = new String[]{BaseColumns._ID,
                NotesDbAdapter.KEY_TITLE,
                NotesDbAdapter.KEY_BODY};

        int[] to = new int[]{R.id.id, R.id.title, R.id.body};
        mAdapter = new SimpleCursorAdapter(
                this, R.layout.note_row, c, from, to, 0);

        setListAdapter(mAdapter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        dbAdapter.close();
    }

    @Override
    public void onClick(View v) {
        String txt, txt1, txt2;
        int btn = v.getId();
        switch (btn) {
            case R.id.insert_btn:
                txt1 = tv2.getText().toString().trim();
                txt2 = tv3.getText().toString().trim();
                if (txt1.length() != 0 && txt2.length() != 0) {
                    dbAdapter.insertNote(txt1, txt2);
                    toastMemo("insert - success");
                } else {
                    toastMemo("insert - faliure");
                }
                break;

            case R.id.update_btn:
                txt = tv1.getText().toString().trim();
                txt1 = tv2.getText().toString().trim();
                txt2 = tv3.getText().toString().trim();
                if (txt1.length() != 0 && txt2.length() != 0) {
                    if (dbAdapter.updateNote(txt, txt1, txt2))
                        toastMemo("update - success");
                    else
                        toastMemo("updatet - faliure");
                }
                break;
            case R.id.delete_btn:
                txt = tv1.getText().toString().trim();
                if (dbAdapter.deleteNote(txt))
                    toastMemo("delete - success");
                else
                    toastMemo("delete - faliure");
                break;
        }
        tv1.setText("");
        tv2.setText("");
        tv3.setText("");
        setEnabled(false);
        Cursor c = dbAdapter.fetchAllNotes();
        mAdapter.changeCursor(c);
        mAdapter.notifyDataSetChanged();
    }
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id){
        super.onListItemClick(l, v, position, id);
        ConstraintLayout container = (ConstraintLayout) v;
        TextView id_tv = (TextView)container.findViewById(R.id.id);
        TextView title_tv = (TextView)container.findViewById(R.id.title);
        TextView body_tv = (TextView)container.findViewById(R.id.body);
        tv1.setText(id_tv.getText());
        tv2.setText(title_tv.getText());
        tv3.setText(body_tv.getText());
        setEnabled(true);
    }

    private void setEnabled(boolean enabled) {
        update_btn.setEnabled(enabled);
        delete_btn.setEnabled(enabled);
    }


    private void toastMemo(String str) {
        if (str.length() ==0)
            return;
        Toast toast = Toast.makeText(
                getApplicationContext(), str, Toast.LENGTH_LONG);
        toast.show();
    }
}
