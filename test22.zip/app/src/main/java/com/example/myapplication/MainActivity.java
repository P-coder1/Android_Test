package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText editText;
    Button btn01;
    WebView web01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText)findViewById(R.id.editText);

        btn01 =(Button)findViewById(R.id.button);
        btn01.setOnClickListener(this);

        web01 = (WebView)findViewById(R.id.webview01);

        web01.setWebViewClient(new WebViewClient());

        web01.getSettings().setJavaScriptEnabled(true);
        web01.getSettings().setBuiltInZoomControls(true);
        web01.clearCache(true);
    }

    @Override
    public void onClick(View view) {
        String url = editText.getText().toString();
        web01.loadUrl(url);
    }
}
