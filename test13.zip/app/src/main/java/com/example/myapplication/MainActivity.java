package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.ContentResolver;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView text01;
    Button btn01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn01 = (Button) findViewById(R.id.button01);
        btn01.setOnClickListener(this);

        text01 = (TextView)findViewById(R.id.textView1);
        ActivityCompat.requestPermissions(this, new  String[]
                {Manifest.permission.WRITE_EXTERNAL_STORAGE}, MODE_PRIVATE);
    }

    @Override
    public void onClick(View view) {
        ContentResolver cr = getContentResolver();

        Cursor c = cr.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                null , null , null, MediaStore.Audio.Media.TITLE + "ASC");

        int albumldx = ((Cursor) c).getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
        int titleldx = ((Cursor) c).getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);
        int artistldx = ((Cursor) c).getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);

        StringBuffer buff = new StringBuffer();

        buff.append("Music List\n\n");

        if(c.moveToFirst()) {
            do{
                buff.append(c.getString(albumldx));
                buff.append("\n");
                buff.append(c.getString(titleldx));
                buff.append("\n");
                buff.append(c.getString(artistldx));
                buff.append("\n");
                buff.append("----------------\n");
            } while (c.moveToNext());
        }

        text01.setText(buff);
    }
}
