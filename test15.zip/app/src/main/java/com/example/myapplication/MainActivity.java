package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.os.Bundle;
import android.os.Environment;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn01;
    TextView text01;

    BufferedReader reader = null;
    FileInputStream fis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn01 = (Button)findViewById(R.id.button1);
        btn01.setOnClickListener(this);

        text01 = (TextView)findViewById(R.id.textView2);

        text01.setMovementMethod(new ScrollingMovementMethod());

        ActivityCompat.requestPermissions(this, new String[]
                {Manifest.permission.WRITE_EXTERNAL_STORAGE}, MODE_PRIVATE);
    }

    @Override
    public void onClick(View v) {
        try {
            File path = new File(Environment.getExternalStorageDirectory().getAbsolutePath()
                    + "/datafile.txt");
            fis = new FileInputStream(path);

            reader = new BufferedReader(new InputStreamReader(fis, "UTF-8"));

            String s;

            while ((s = reader.readLine()) != null);{
                text01.append(s); // s = data/file/test 가 찍힘
                text01.append("\n");

                String [] temp = s.split("/");  // split을 이용하여 배열로 받아 내용을 다 입력 한 뒤 /를 기준으로 짜름
                text01.append(temp[0]); // temp의 0번쨰에 붙임
                text01.append("\n");
                text01.append(temp[1]); // temp의 1번쨰에 붙임
                text01.append("\n");
                text01.append(temp[2]); // temp의 2번쨰에 붙임
                text01.append("\n");
                text01.append("\n--------------------------\n");

            }
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
