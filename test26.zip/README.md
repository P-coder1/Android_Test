# fcmTestApp
Extremely Basic Android app that show use of Google FCM Message for Background and Foreground Use

App literally does nothing other than show basic template activity but can then respond to push notifications from Google FCM using for example console tools such as firebase console https://console.firebase.google.com/

Note: the application uses Channel "123" as message channel so when sending notifications they must be assigned to Channel 123

When using the firebase console need to register a new project and for sending test messages, get unique client Id from the application using the debug tools.



