package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class NotesDbAdapter {
    private  static  final  String DATABASE_NAME = "data";
    private  static  final  int DATABASE_VERSION = 2;
    private  static  final  String DATABAE_TABLE = "notes";
    static  final  String KEY_ROWID ="_id";
    static  final  String KEY_TITLE ="title";
    static  final  String KEY_BODY = "body";
    static  final  String KEY_BODY2 = "body2";

    private  static  final  String CREATE_TABLE =
            "create table notes (_id integer primary key autoincrement, "
            +"title text not null, body text not null ,body2 text not null);";

    private  static final  String TAG = "NotesDbAdapter";

    private SQLiteDatabase mDb;

    private  DatabaseHelper mDbHepler;

    private final Context mCtx;

    private  static  class DatabaseHelper extends SQLiteOpenHelper{
        public  DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null,DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(CREATE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.w(TAG,"Upgrading database from version" + oldVersion +"to"
                + newVersion +", which will destory all old data");
            db.execSQL("DROP TABLE IF EXISTS notes");
            onCreate(db);
        }
    }
    public  NotesDbAdapter(Context ctx){
        this.mCtx = ctx;
    }

    public NotesDbAdapter open() throws SQLException{
        mDbHepler = new DatabaseHelper(mCtx);
        mDb = mDbHepler.getWritableDatabase();
        return this;
    }

    public  void close(){
        mDbHepler.close();
    }

    public long insertNote(String title, String body, String body2){
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_TITLE, title);
        initialValues.put(KEY_BODY, body);
        initialValues.put(KEY_BODY2, body2);
        return  mDb.insert(DATABAE_TABLE, null,initialValues);
    }

    public Cursor fetchAllNotes(){
        return  mDb.query(DATABAE_TABLE,new String[]{KEY_ROWID,KEY_TITLE,
                KEY_BODY,KEY_BODY2}, null,null,null,null,"_id DESC");
    }
    public boolean updataNote(String rowld, String title, String body, String body2){
        ContentValues args = new ContentValues();
        args.put(KEY_TITLE, title);
        args.put(KEY_BODY,body);
        args.put(KEY_BODY2,body2);
        return mDb.update(DATABAE_TABLE, args, KEY_ROWID +"="+ rowld,null) >0;
    }
    public  boolean deleteNote(String rowId){
        Log.i("Delete called","value__"+rowId);
        return mDb.delete(DATABAE_TABLE,KEY_ROWID+"="+ rowId,null) >0;
    }
}
