package com.example.myapplication;

import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.ListActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends ListActivity implements View.OnClickListener {

    private NotesDbAdapter dbAdapter;
    private SimpleCursorAdapter mAdapter;

    private EditText tv,tv1,tv2 ,tv3;
    private Button insert_btn, update_btn, delete_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = (EditText)findViewById(R.id.editText01);
        tv1 = (EditText)findViewById(R.id.editText02);
        tv2 = (EditText)findViewById(R.id.editText03);
        tv3 = (EditText)findViewById(R.id.editText04);
        tv.setEnabled(false);

        insert_btn =(Button)findViewById(R.id.button01);
        update_btn =(Button)findViewById(R.id.button02);
        delete_btn =(Button)findViewById(R.id.button03);
        insert_btn.setOnClickListener(this);
        update_btn.setOnClickListener(this);
        delete_btn.setOnClickListener(this);
    }
    @Override
    protected  void onResume(){
        super.onResume();
        dbAdapter = new NotesDbAdapter(this);
        dbAdapter.open();
        Cursor c = dbAdapter.fetchAllNotes();
        startManagingCursor(c);

        String[] from = new String[]{BaseColumns._ID,
            NotesDbAdapter.KEY_TITLE,
            NotesDbAdapter.KEY_BODY,
                NotesDbAdapter.KEY_BODY2};

        int[] to = new int[] {R.id._id, R.id.title, R.id.body, R.id.body2};

        mAdapter = new SimpleCursorAdapter(
                this, R.layout.note_row, c,from, to,0);

        setListAdapter(mAdapter);


    }
    @Override
    protected void onPause(){
        super.onPause();
        dbAdapter.close();
    }

    @Override
    public void onClick(View v) {
        String txt, txt1, txt2, txt3;
        int btn= v.getId();
        switch (btn){
            case R.id.button01 :
                txt1=tv1.getText().toString().trim();
                txt2=tv2.getText().toString().trim();
                txt3=tv3.getText().toString().trim();
                if(txt1.length()!=0 && txt2.length()!=0 && txt3.length()!=0) {
                    dbAdapter.insertNote(txt1, txt2, txt3);
                    toastMemo("insert - success");
                }else{
                    toastMemo("insert - failure");

                }
                break;
            case R.id.button02 :
                txt=tv.getText().toString().trim();
                txt1=tv1.getText().toString().trim();
                txt2=tv2.getText().toString().trim();
                txt3=tv3.getText().toString().trim();
                if(txt1.length()!=0 && txt2.length()!=0&& txt3.length()!=0){
                    if(dbAdapter.updataNote(txt,txt1,txt2,txt3))
                        toastMemo("update - success");
                    else
                        toastMemo("update - failure");
                }
                break;
            case R.id.button03 :
                txt=tv.getText().toString().trim();
                if(dbAdapter.deleteNote(txt))
                    toastMemo("delete - success");
                else
                    toastMemo("delete - failure");
                break;
        }
        tv.setText("");
        tv1.setText("");
        tv2.setText("");
        tv3.setText("");
        setEnabled(false);
        Cursor c = dbAdapter.fetchAllNotes();
        mAdapter.changeCursor(c);
        mAdapter.notifyDataSetChanged();
    }
    @Override
    protected void onListItemClick(ListView l, View v, int position, long id){
        super.onListItemClick(l,v,position,id);
        ConstraintLayout continer = (ConstraintLayout) v;
        TextView id_tv = (TextView)continer.findViewById(R.id._id);
        TextView title_tv =(TextView)continer.findViewById(R.id.title);
        TextView body_tv = (TextView)continer.findViewById(R.id.body);
        TextView body_tv2 = (TextView)continer.findViewById(R.id.body2);
        tv.setText(id_tv.getText());
        tv1.setText(title_tv.getText());
        tv2.setText(body_tv.getText());
        tv3.setText(body_tv2.getText());
        setEnabled(true);
    }
    private  void setEnabled(boolean enabled){
        update_btn.setEnabled(enabled);
        delete_btn.setEnabled(enabled);
    }
    private void toastMemo(String str){
        if(str.length() == 0)
            return;
        Toast toast = Toast.makeText(
                getApplicationContext(),str, Toast.LENGTH_LONG);
        toast.show();
    }
}
