package com.example.seoil.myapplication;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView text01,btn01 ,btn02;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        text01 = (TextView) findViewById(R.id.textView);
        registerForContextMenu(text01);

        btn01 = (Button)findViewById(R.id.button);
        btn01.setOnClickListener(this);


        btn02 = (Button)findViewById(R.id.button);
        btn02.setOnClickListener(this);

    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        if (v.getId() == R.id.textView)
            getMenuInflater().inflate(R.menu.menu, menu);
    }

    public boolean onContextltemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.item01:
                Toast.makeText(this, "Font Size +", Toast.LENGTH_LONG).show();
                break;
            case R.id.item02:
                Toast.makeText(this, "Font Size -", Toast.LENGTH_LONG).show();
                break;

            case R.id.item11:
                text01.setBackgroundColor(0xFFFF0000);
                break;
            case R.id.item12:
                text01.setBackgroundColor(Color. GREEN);
                break;
            case R.id.item13:
                text01.setBackgroundColor(Color. BLUE);
                break;
        }
        return  super.onContextItemSelected(item);
    }

    @Override
    public void onClick(View v) {

    }
}
