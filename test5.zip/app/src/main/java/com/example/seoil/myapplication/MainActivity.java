package com.example.seoil.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    ArrayList<String> Items;
    ArrayAdapter<String> Adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button btn01 = (Button)findViewById(R.id.button);
        btn01.setOnClickListener(this);

        Button btn02 = (Button)findViewById(R.id.button);
        btn02.setOnClickListener(this);

        ListView lv = (ListView)findViewById(R.id.listView01);
        lv.setAdapter(Adapter);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id){
                ListView lv = (ListView)parent;
                String selected = (String)lv.getItemAtPosition(position);
            }
        });
    }
    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.button){
            EditText et = (EditText) findViewById(R.id.editText);
            Items.add(et.getText().toString());
            et.setText("");
            Adapter.notifyDataSetChanged();
        }
        if (v.getId() == R.id.button2){
            finish();
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int positoin . long id){
        Toast.makeText(this, "Item : " + positoin + "long = " + id.To)
    }
}
