package com.example.seoil.asdf;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity2 extends AppCompatActivity implements  View.OnClickListener{

    EditText editText01;
    Button button01, button02, button03, button04;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        editText01 = (EditText)findViewById(R.id.editText);
        button01 = (Button)findViewById(R.id.button);
        button02 = (Button)findViewById(R.id.button2);
        button03 = (Button)findViewById(R.id.button3);
        button04 = (Button)findViewById(R.id.button4);

        button01.setOnClickListener(this);
        button02.setOnClickListener(this);
        button03.setOnClickListener(this);
        button04.setOnClickListener(this);

    }
    public void onClick(View v){  //call back method  _자동으로 불리는 함수
        if(v.getId()==R.id.button) {
            editText01.setText("");
        }
        if(v.getId()==R.id.button2) {
            finish();
        }
        if(v.getId()==R.id.button3) {
            editText01.setText("201508403 고태민");
        }
        if(v.getId()==R.id.button4) {
            Intent intent01 = new Intent(MainActivity2.this, MainActivity3.class); // Intent(누가.this , 누구에게.class)    //선언만 함
            startActivity(intent01);  //만들어놓은 Intent(intent01)를 전송

        }
    }
}
