package com.example.seoil.myapplication;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edit01;
    Button btn01,btn02,btn03;
    SharedPreferences spref;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit01 =(EditText)findViewById(R.id.editText);

        btn01 =(Button)findViewById(R.id.button1);
        btn02 =(Button)findViewById(R.id.button2);
        btn03 =(Button)findViewById(R.id.button3);

        btn01.setOnClickListener(this);
        btn02.setOnClickListener(this);
        btn03.setOnClickListener(this);

        spref = getSharedPreferences("gpref",MODE_PRIVATE);
        editor = spref.edit();

        String temp1 =spref.getString("editText1","1");

        edit01.setText(temp1);
    }

    @Override
    public void onClick(View v) {
        String txt01;
        txt01 = edit01.getText().toString();
        if(v.getId() == R.id.button1){
            editor.putString("editText",txt01);
            editor.commit();
        }
        if(v.getId() == R.id.button2) {
            edit01.setText("");
        }
        if(v.getId() == R.id.button3) {
            edit01.append("\n"+"ADD_TEXT!");
        }
        if(v.getId() == R.id.button4){
            finish();
        }
    }
}
