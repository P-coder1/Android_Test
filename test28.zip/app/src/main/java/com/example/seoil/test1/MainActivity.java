package com.example.seoil.test1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements  View.OnClickListener{

    Button btn01, btn02;
    EditText input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn01 = (Button)findViewById(R.id.button1);
        btn02 = (Button)findViewById(R.id.button2);
        input = findViewById(R.id.editText3);
;
        btn01.setOnClickListener(this);
        btn02.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.button1) {
            String temp = input.getText().toString();
            Intent intent01 = new Intent(MainActivity.this, Main2Activity.class);
            intent01.putExtra("name", temp);
            startActivity(intent01);
        }
        if (v.getId() == R.id.button2){
            finish();
        }
    }
}
