package com.example.seoil.test1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener {

    Button btn03;
    TextView text01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Intent data_receive;
        data_receive = getIntent();
        String temp01 = data_receive.getStringExtra("name");


        text01 = (TextView)findViewById(R.id.result_textView);
        text01.setText(temp01);

        btn03 = (Button)findViewById(R.id.button3);
        btn03.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        finish();
    }
}
