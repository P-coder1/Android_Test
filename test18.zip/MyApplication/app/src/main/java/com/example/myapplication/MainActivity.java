package com.example.myapplication;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private static final int NOTIFY_1= 0x1001;
    private NotificationManager notifier = null;
    Notification notifiy = new Notification();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        notifier =(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

        Button button01 = (Button)findViewById(R.id.button);
        button01.setOnClickListener(this);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onClick(View view) {
        String expandedTitle = "E-Title";
        String expandedText= "Content";
        String titkerText = "Notification !!!";

        Intent toLaunch = new Intent(MainActivity.this, Notifications.class);

        PendingIntent intentBack = PendingIntent.getActivity(MainActivity.this,
                0,toLaunch, 0);

        if(Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            notifiy = new Notification.Builder(getApplication())
                    .setContentTitle(expandedTitle)
                    .setContentText(expandedText)
                    .setTicker(titkerText)
                    //.setSmallIcon(R.drawable.ic_launcher_background)
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setAutoCancel(true)
                    .setContentIntent(intentBack)
                    .setWhen(System.currentTimeMillis())
                    .build();
        }

        if(Build.VERSION.SDK_INT >=  Build.VERSION_CODES.O) {

            NotificationChannel channelMessage = new NotificationChannel("channel_id",
                    "channel_name", NotificationManager.IMPORTANCE_DEFAULT);
            channelMessage.setDescription("channerl description");
            channelMessage.enableLights(true);
            channelMessage.setLightColor(Color.GREEN);
            channelMessage.enableVibration(true);
            channelMessage.setVibrationPattern(new long[]{100, 200, 100, 200});
            channelMessage.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            notifier.createNotificationChannel(channelMessage);

            notifiy = new NotificationCompat.Builder(getApplication(), "channel_id")
                    .setContentTitle(expandedTitle)
                    .setContentText(expandedText)
                    .setTicker(titkerText)
                    //.setSmallIcon(R.drawable.ic_launcher_background) // 21보다 낮은 버전은 백그라운드로 이상은 포그라운드로 함
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setAutoCancel(true)
                    .setContentIntent(intentBack)
                    .setWhen(System.currentTimeMillis())
                    .build();

        }
        notifier.notify(NOTIFY_1, notifiy);
    }
}
