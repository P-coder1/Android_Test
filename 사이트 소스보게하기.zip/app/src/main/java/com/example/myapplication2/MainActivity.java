package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    EditText edit01;
    Button btn01;
    TextView text01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn01 = (Button) findViewById(R.id.button3);
        btn01.setOnClickListener(this);

        edit01 = (EditText) findViewById(R.id.editText3);

        text01 = (TextView) findViewById(R.id.textView);

    }

    @Override
    public void onClick(View view) {
        if (isNetworkAvailable()) {
            DownloadTask downloadTask = new DownloadTask();
            downloadTask.execute(edit01.getText().toString());
        } else {
            Toast.makeText(getBaseContext(),
                    "Network is not Available", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isNetworkAvailable() {
        boolean available = false;
        ConnectivityManager connMgr =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isAvailable())
            available = true;
        return available;
    }

    private class DownloadTask extends AsyncTask<String, Integer, String> {

        String s = null;

        @Override
        protected String doInBackground(String... params) {
            try {
                s = downloadUrl(params[0]);
            } catch (Exception e) {
                Log.d("Background Task", e.toString());
            }
            return s;
        }


        protected void onPostExecute(String result) {
            text01.setText(result);
            Toast.makeText(getBaseContext(),
                    "Web page downloaded successfully", Toast.LENGTH_LONG).show();
        }

        protected void onPreExecute() {
            Toast.makeText(getBaseContext(),
                    "onPreExecute()", Toast.LENGTH_LONG).show();
        }
    }

        private String downloadUrl(String strUrl) throws IOException {
            String s = null;
            byte[] buffer = new byte[1000];
            InputStream iStream = null;
            try {
                URL url = new URL(strUrl);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.connect();
                iStream = urlConnection.getErrorStream();
                iStream.read(buffer);
            } catch (Exception e) {
                Log.d("Exception downloading", e.toString());
            } finally {
                iStream.close();
            }
            return s;
        }
}
