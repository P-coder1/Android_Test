package com.example.seoil.a20190412;

import android.content.Intent;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int START_ACTVITY1 = 1;
    private static final int START_ACTVITY2 = 2;

    EditText input_edit01;
    Button btn01, btn02, btn03;
    TextView result_text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        input_edit01 = (EditText)findViewById(R.id.editText1);

        btn01 = (Button)findViewById(R.id.button1);
        btn01.setOnClickListener(this);

        btn02 = (Button)findViewById(R.id.button2);
        btn01.setOnClickListener(this);

        btn03 = (Button)findViewById(R.id.button3);

    }


    @Override
    public void onClick(View v) {
    if(v.getId() == R.id.button1){
        String s = input_edit01.getText().toString();
        Intent intent01 = new Intent(MainActivity.this, SecondActivity.class);
        intent01.putExtra(SecondActivity.SEND_DATA, s);
        startActivityForResult(intent01, START_ACTVITY1);
    }
        if(v.getId() == R.id.button2) {
            String s = input_edit01.getText().toString();
            Intent intent01 = new Intent(MainActivity.this, SecondActivity.class);
            intent01.putExtra(SecondActivity.SEND_DATA, s);
            startActivityForResult(intent01, START_ACTVITY2);
        }

        if(v.getId() == R.id.button3) {
        finish();
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        result_text =(TextView)findViewById(R.id.textView);
        if(requestCode==START_ACTVITY1){
            if(resultCode != RESULT_OK){
                result_text.setText("Data Error");
            }
            if(resultCode == RESULT_OK){
                String result = data.getExtras().getString((String) SecondActivity.RESULT_DATA);
                result_text.setText(result);
            }
        }
        if(requestCode==START_ACTVITY2){
            if(resultCode != RESULT_OK){
                result_text.setText("Data Error");
            }
            if(resultCode == RESULT_OK){
                String result = data.getExtras().getString((String) SecondActivity.RESULT_DATA);
                result_text.setText(result);
            }
        }
    }

}
