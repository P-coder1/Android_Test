package com.example.seoil.myapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener {

    EditText edit01;  // 회색으로 된 이유는 선언은 했는데 안쓰고 있다는 뜻
    Button btn01, btn02, btn03 ,btn04;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edit01 = (EditText)findViewById(R.id.editText); // 리소스 아이디에 에디터 텍스트를 연결
        btn01 = (Button)findViewById(R.id.button); // 버튼 1과 2를 불러드림
        btn02 = (Button)findViewById(R.id.button2);
        btn03 = (Button)findViewById(R.id.button3);
        btn04 = (Button)findViewById(R.id.button4);


        btn01.setOnClickListener(this); // 사용자가 버튼을 누르면 이벤트를 감지해서 nClickListener한테 통지가 가고 onClick 메소드에 있는 것을 통지를 함
        btn02.setOnClickListener(this);
        btn03.setOnClickListener(this);
        btn04.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) { // 콜랭 메소드 라고 함 : 어떤 것이 수행될떄 자동으로 호출하는 것을 말함
        if(v.getId() == R.id.button) { // 뷰의 겟아이디가 버튼을 누르는 이벤트를 불러옴
            edit01.setText(""); // edit01은 글씨를 설정합니다 = 누르면 내용이 지워짐
            //코드 구현
        }
        if(v.getId() == R.id.button2) { // 종료 버튼
            // 구현
            finish(); // 종료
        }
        if(v.getId()==R.id.button3) {
            edit01.setText("201406655_편민형"); // setText는 안에 있는 문자를 출력해주는 역할

        }
        Intent intent01 = new Intent(MainActivity.this,SecondActivity.class);
        startActivity(intent01);
    }
}
