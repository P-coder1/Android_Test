package com.example.myapplication3;

import android.Manifest;
import android.app.Activity;
import android.os.Environment;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn01;
    TextView text01;

    BufferedReader reader = null;
    FileInputStream fis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn01 = (Button)findViewById(R.id.button1);
        btn01.setOnClickListener(this);

        text01 = (TextView)findViewById(R.id.textView2);

        text01.setMovementMethod(new ScrollingMovementMethod());

        ActivityCompat.requestPermissions(this, new String[]
                {Manifest.permission.WRITE_EXTERNAL_STORAGE}, MODE_PRIVATE);
    }

    @Override
    public void onClick(View v) {
        try {
            File path = new File(Environment.getExternalStorageDirectory().getAbsolutePath()
                        + "/datafile.txt");
            fis = new FileInputStream(path);

            reader = new BufferedReader(new InputStreamReader(fis, "UTF-8"));

            String s;

            while ((s = reader.readLine()) != null);
            text01.append(s);
            text01.append("\n");
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
