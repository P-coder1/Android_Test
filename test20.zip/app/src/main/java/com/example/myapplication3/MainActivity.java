package com.example.myapplication3;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.CallLog;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


    Cursor c;
    ContentResolver cr;
    String[] progection;
    StringBuffer buff;
    TextView text01;
    Button btn01;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progection = new String[]{
                CallLog.Calls.TYPE,
                CallLog.Calls.NUMBER,
                CallLog.Calls.DURATION,
                CallLog.Calls.DATE,
                CallLog.Calls.CACHED_NAME
        };

        text01 = (TextView)findViewById(R.id.textView2);
        text01.setMovementMethod(new ScrollingMovementMethod());

        btn01 = (Button)findViewById(R.id.button1);
        btn01.setOnClickListener(this);

        buff = new StringBuffer();
        buff.append("History \n\n");

        ActivityCompat.requestPermissions(this,new String[]{
                Manifest.permission.READ_CALL_LOG}, MODE_PRIVATE);
    }

    @Override
    public void onClick(View view) {

        cr = getContentResolver();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            //권한을 획득했는지 확인
            return;
        }

        c = cr.query(CallLog.Calls.CONTENT_URI, progection, null, null, "date desc");

        if (c.moveToFirst()){
            do {
                if (c.getInt(0) == CallLog.Calls.OUTGOING_TYPE){
                    buff.append("-->OUTGOING");
                }
                if (c.getInt(0) == CallLog.Calls.MISSED_TYPE){
                    buff.append("?--MISSED");
                }

                if (c.getInt(0) == CallLog.Calls.REJECTED_TYPE){
                    buff.append("X--REJECTED");
                }
                if (c.getInt(0) == CallLog.Calls.INCOMING_TYPE){
                    buff.append("<--INCOMING");
                }
                if (c.getString(0) == CallLog.Calls.DATE){
                    buff.append("--DATE");
                }
                if (c.getString(0) == CallLog.Calls.CACHED_NAME){
                    buff.append("--CACHED_NAME");
                }



                buff.append("\t : ");
                buff.append(c.getString(1));
                buff.append("\t : ");
                buff.append(c.getInt(2));

                /*
                Date date1 = new Date(c.getLong(3)): // 뽑은 값을 가지고
                SimpleDateFormat date = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss a");   // 년 월 일 시간 분 초를 보여준다.
                String date2= date.format(date1): // 여기 포멧으로 변경하여 date 2에 담는다
                buff.append(c.getInt(2)):
                */

                buff.append("\t : \n");
                buff.append(c.getString(3));
                buff.append("\t : ");
                buff.append(c.getString(4));
                buff.append("\t : \n");
                buff.append("\n--------------------------------\n");
            }while (c.moveToNext());
        }

        c.close();

        text01.setText(buff);
    }
}
